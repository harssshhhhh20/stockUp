package com.stockup.backend.domain.store.entity.enums;

public enum BusinessType {

    GROCERY,
    PHARMACY,
    HARDWARE,
    BUILDING_MATERIAL,
    ELECTRICAL,
    STATIONERY,
    BEAUTY,
    PET_SUPPLIES,
    GENERAL_STORE,
    OTHER

}