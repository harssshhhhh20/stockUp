package com.stockup.backend.domain.store.entity;

import com.stockup.backend.common.persistence.entity.AuditableEntity;
import com.stockup.backend.domain.merchant.entity.Merchant;
import com.stockup.backend.domain.store.entity.enums.BusinessType;
import jakarta.persistence.*;

@Entity
@Table(name = "stores")
public class Store extends AuditableEntity {
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "merchant_id",
            nullable = false,
            unique = true
    )
    private Merchant merchant;

    @Column(nullable = false, length = 150)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "business_type", nullable = false)
    private BusinessType businessType;
}