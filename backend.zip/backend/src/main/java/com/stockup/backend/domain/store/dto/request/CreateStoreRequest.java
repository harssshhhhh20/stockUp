package com.stockup.backend.domain.store.dto.request;

import com.stockup.backend.domain.store.entity.enums.BusinessType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CreateStoreRequest(

        @NotBlank
        @Size(max = 150)
        String name,

        @NotNull
        BusinessType businessType
) {
}
