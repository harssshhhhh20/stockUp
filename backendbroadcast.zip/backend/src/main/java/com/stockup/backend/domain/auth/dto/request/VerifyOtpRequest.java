package com.stockup.backend.domain.auth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record VerifyOtpRequest(

        @NotBlank(message = "Email is required.")
        @Email(message = "Invalid email address.")
        String email,

        @NotBlank(message = "OTP is required.")
        @Pattern(regexp = "\\d{6}", message = "OTP must be 6 digits.")
        String otp

) {
}